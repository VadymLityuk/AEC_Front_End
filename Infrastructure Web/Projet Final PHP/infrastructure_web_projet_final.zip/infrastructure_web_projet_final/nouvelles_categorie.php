<?php include_once('include/header.php'); ?>

  <!-- Page Content -->
  <div class="container">
  
	<h1 class="my-4">(Afficher le titre de la catégorie ici)</h1>
	<!-- Afficher la liste de toutes nouvelles ACTIVES appartenant à la catégorie sélectionnée en ordre chronologique (de la plus récente à la plus ancienne) -->
	<!-- L'affichage est à votre discrétion -->
	
  </div>

<?php include_once('include/footer.php'); ?>

