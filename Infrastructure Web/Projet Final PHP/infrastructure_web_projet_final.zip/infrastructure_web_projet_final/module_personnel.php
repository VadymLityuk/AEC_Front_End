<?php include_once('include/header.php'); ?>

  <!-- Page Content -->
  <div class="container">
  
	<h1 class="my-4">Module personnel</h1>	
	<p>(Remplacez ce paragraphe par une courte phrase qui explique l'information qui est affichée par le module)</p>
	
	<!-- Affichez les enregistrement de la table que vous avez ajoutée à la base de données. -->
	
  </div>

<?php include_once('include/footer.php'); ?>
